package TP_Excepciones;

public class matriculaVencidaException extends Exception{
    public matriculaVencidaException(String msg){
        super(msg);
    }
}
