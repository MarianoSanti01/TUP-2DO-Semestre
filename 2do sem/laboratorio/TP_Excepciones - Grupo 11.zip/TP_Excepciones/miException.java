package TP_Excepciones;

public class miException extends Exception{
    public miException(String msg){
        super(msg);
    }
}
