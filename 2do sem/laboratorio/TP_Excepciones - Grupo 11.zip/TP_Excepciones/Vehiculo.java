package TP_Excepciones;

public abstract class Vehiculo {
    protected String brand;
    protected String model;
    protected float speed;

    public Vehiculo(String brand, String model, float speed) {
        this.brand = brand;
        this.model = model;
        this.speed = speed;
    }

    public float getSpeed() {
        return speed;
    }

    public abstract void speedUp(float speedRise);
}
