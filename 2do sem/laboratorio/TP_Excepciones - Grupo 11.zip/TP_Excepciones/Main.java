package TP_Excepciones;

import java.util.Date;

public class Main {
    public static void main(String[] args) {
        Auto a1=new Auto("Fiat", "Qubo", 46.7f);
        Camion c1=new Camion("Scania", "Turbo", 28.5f);

        a1.speedUp(50);
        System.out.println(a1.getSpeed());

        c1.speedUp(100);

        Matricula m1=new Matricula(23413, new Date(2020, 3, 12));
        Matricula m2=new Matricula(23643, new Date(2009, 9, 9));

        Chofer ch1=new Chofer("Carlos Juárez", m1);
        Chofer ch2=new Chofer("Ana Darién", m2);

        c1.addDriver(ch1);
        c1.addDriver(ch2);
    }
}
