package TP_Excepciones;

public class Auto extends Vehiculo{
    public Auto(String brand, String model, float speed) {
        super(brand, model, speed);
    }



    public void speedUp(float speedRise){
        float totalSpeed=speed+speedRise;
        try{
            if (totalSpeed > 120f){
                throw new miException("El auto tiene prohibido acelerar");
            }else{
                speed+=speedRise;
            }
        }catch(miException e) {
            System.out.println(e.getMessage());
        }
    }
}
