package TP_Excepciones;

import java.sql.SQLOutput;

public class Camion extends Vehiculo{
    private Chofer driver;
    public Camion(String brand, String model, float speed) {
        super(brand, model, speed);
    }

    public void speedUp(float speedRise){
        float totalSpeed=speed+speedRise;
        try{
            if (totalSpeed > 120f){
                throw new miException("El camión tiene prohibido acelerar");
            }else{
                speed+=speedRise;
            }
        }catch(miException e){
            System.out.println(e.getMessage());
        }
    }

    public void addDriver(Chofer driver){
        if(driver.licenceCheck(driver.getLicence())){
            this.driver=driver;
            System.out.println("El chofer "+driver.getName()+" ha sido agregado");
        }
    }
}
