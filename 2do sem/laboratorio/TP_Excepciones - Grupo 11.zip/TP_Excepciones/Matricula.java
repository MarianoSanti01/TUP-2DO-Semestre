package TP_Excepciones;

import java.util.Date;

public class Matricula {
    private int number;
    private Date licenceDate;

    public Matricula(int number, Date licenceDate) {
        this.number = number;
        this.licenceDate = licenceDate;
    }

    public Date getLicenceDate() {
        return licenceDate;
    }
}
