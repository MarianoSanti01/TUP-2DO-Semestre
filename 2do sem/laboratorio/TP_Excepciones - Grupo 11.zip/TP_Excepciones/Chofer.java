package TP_Excepciones;

import java.util.Date;

public class Chofer {
    private String name;
    private Matricula licence;

    public Chofer(String name, Matricula licence) {
        this.name = name;
        this.licence = licence;
    }

    public Matricula getLicence() {
        return licence;
    }

    public String getName() {
        return name;
    }

    public boolean licenceCheck(Matricula licence) {
        Date refDate=new Date(2010, 4, 24);
        boolean licChecker=false;
        try {
            if (licence.getLicenceDate().before(refDate)) {
                licChecker =false;
                throw new matriculaVencidaException("La matrícula de "+name+" está vencida");
            }else{
                licChecker=true;
            }
        }catch (matriculaVencidaException e) {
            System.out.println(e.getMessage());
        }
        return licChecker;
    }
}
